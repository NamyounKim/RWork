#=================================================================================================================
# 이니스프리몰 리뷰 스코어 산출 Script
# Date : 2018.05.14
# Writer : 김남윤
#=================================================================================================================
options(java.parameters = "-Xmx5g")
library(dplyr)
library(stringi)
library(NLP4kec)
library(readr)
library(data.table)
library(tm)
library(wordVectors)
library(stringr)
library(slam)

source("/home/r_srcs/apa/batch_job/ref_function/tm_function.R")
source("/home/r_srcs/apa/batch_job/ref_function/createImpalaConnection.R")
connImpala = getImpalaConnection()

# 조회 날짜범위 세팅 (직접 세팅!!!)
start_date = "2018-01-01"
end_date = "2018-05-13"

start_date = paste0(stri_replace_all_fixed(start_date, "-",""), "000000")
end_date = paste0(stri_replace_all_fixed(end_date, "-",""), "235959")

# 1. Data Load for Review ----------------------------------------------------------------------------------------

# 1-1. 리뷰 원문
# review 데이터 가져오기
query = paste0(
"SELECT 
    A.reviewseq,
    A.prdseq,
    A.regdate,
    B.tplcl,
    B.tplseq,
    B.tplcnt
FROM lake_legacy_ods.inm_nbbs03mt A
INNER JOIN(
    SELECT 
        reviewseq,
        tplseq,
        tplcl,
        tplcnt
    FROM lake_legacy_ods.inm_nbbs03dt)B 
ON A.reviewseq = B.reviewseq
WHERE A.regdate BETWEEN '", start_date, "' AND '", end_date, "';")
raw_review = dbGetQuery(connImpala, query)


# 템플릿으로 구분된 리뷰 처리 (중복 reviewseq 처리)
dupReviewSeq = unique(raw_review[duplicated(raw_review$reviewseq),1])

if(length(dupReviewSeq) != 0){
  mergeReview = NULL
  mergePrdseq = NULL
  mergeRegDate = NULL
  
  for(i in 1:length(dupReviewSeq)){
    selectDupReview = raw_review %>% as_tibble() %>% filter(reviewseq == dupReviewSeq[i]) %>% arrange(tplseq)
    selectDupReview$tplcnt[is.na(selectDupReview$tplcnt)] = ""
    mergeReview[i] = stri_paste(selectDupReview$tplcnt, collapse = " ")
    mergePrdseq[i] = selectDupReview$prdseq[1]
    mergeRegDate[i] = selectDupReview$regdate[1]
  }
  raw_review_dup = data.frame(reviewseq = dupReviewSeq
                              ,prdseq = mergePrdseq
                              ,regdate = mergeRegDate
                              ,tplcl = NA
                              ,tplseq = 1
                              ,tplcnt = mergeReview)
  
  raw_review2 = raw_review %>% filter(!(reviewseq %in% dupReviewSeq))
  raw_review2 = rbind(raw_review2, raw_review_dup)
}else{
  raw_review2 = raw_review
}


#날짜 생성
raw_review2 = raw_review2 %>% mutate(regYear = substr(regdate,1,4)
                                     ,regMonth = substr(regdate,5,6)
                                     ,regDay = substr(regdate,7,8)
                                     ,regHour = substr(regdate,9,10))

# NA 제거
raw_review2 =  raw_review2 %>% filter(!is.na(tplcnt))


# 형태소 분석용
raw_review2$tplcnt = gsub(",","",raw_review2$tplcnt)
raw_review2$tplcnt = gsub("\"","'",raw_review2$tplcnt)
raw_review2$tplcnt = stri_replace_all_regex(raw_review2$tplcnt, pattern = "[\x80-\xFF]", replacement = "") 
colnames(raw_review2)[c(1,2,6)] = c("v_reviewcd", "v_productcd", "v_content")

# 2. 리뷰별 리뷰 점수 구하기 -----------------------------------------------------------------------------------------------------------------------
#형태소 분석
parsedText = r_parser_r(raw_review2$v_content
                        , language = "ko"
                        , korDicPath = "/home/r_srcs/apa/batch_job/dictionary/dictionary.txt")

# 불용어, 동의어 사전 읽어오기
stopWordDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/stopword_ko.csv")
synonymDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/synonym", trim_ws = F)

# 동의어 처리
parsedText = synonymProcess(targetParsedSet = parsedText)

# make dtm
dtm = makeDtm(parsedText, sr = 0.9999, dtmType = "tf")

m = t(dtm)
cs = col_sums(m) # 총 단어 빈도
m$v = m$v/cs[m$j]

# 고정 IDF값 가져오기
idf_val = readRDS("/home/r_srcs/apa/batch_job/model/idf_tb_inni_0425.RDS")

targetTerm = m$dimnames[1]
targetTerm = targetTerm$Terms
sub_idf_val = idf_val[word %in% targetTerm]

m = m[targetTerm %in% sub_idf_val$word,]

m = m * sub_idf_val$idf_val
dtmMat = as.matrix(t(m))


# 형태소 분석 결과 붙이기
raw_review2$parsedText = parsedText

# 문서별 점수 구하기
raw_review2$tnDl = rowSums(dtmMat) * nchar(raw_review2$v_content)

# 원문 Data set에 붙이기
raw_review2$rown = rownames(raw_review2)
raw_review2$row_sum = rowSums(dtmMat)
raw_review2$char_n = nchar(raw_review2$v_content)
raw_review2$term_n = apply(dtmMat, 1, function(x){length(which(x>0))})
raw_review2$bestYn = ifelse(raw_review2$tnDl >= 1000, TRUE, FALSE)


# 조건에 안 맞는 베스트 리뷰 보정하기 - 단어 개수가 너무 적은 리뷰는 베스트 리뷰에서 제외
modify_target_review = raw_review2 %>% filter(term_n < 15, bestYn == TRUE) %>% select(v_reviewcd)
raw_review2$bestYn[raw_review2$v_reviewcd %in% modify_target_review$v_reviewcd] = FALSE


# 3. 배송/서비스 관련 리뷰 태깅하기 ----------------------------------------------------------------------------------------------------
# word cosine 유사도 불러오기
word_cosine_simility = readRDS("/home/r_srcs/apa/batch_job/model/total_review_cosSim_0514.RDS")

# 속성 키워드 세팅
att_keyword = c("지연","배송","상담원")

# TDM 만들기
tdm_mat = makeDtm(parsedText, 0.999, "tdm-tf")
tdm_mat = as.matrix(tdm_mat)

#속성 스코어 구하기
att_score = getAttributeScore(word_cosine_simility, tdm_mat, att_keyword, cutOff = 0.7)

#원천 테이블에 스코어 붙이기
raw_review2 = cbind(raw_review2, att_score$docScore)

# 배송/서비스 관련 리뷰 보정하기
raw_review2 = raw_review2 %>% mutate(tag = case_when((배송>0 | 지연>0 | 상담원>0) ~ "delivery/service"))


# 4.최종 데이터 셋 만들기 ----------------------------------------------------------------------------------------------------
target_data = raw_review2 %>% select(v_reviewcd, v_productcd, regdate, parsedText, tnDl, char_n, term_n, bestYn, tag)

# 5.베스트리뷰 개수 ----------------------------------------------------------------------------------------------------
target_data %>% group_by(bestYn, tag) %>% summarise(n = n())


