#=================================================================================================================
# 에뛰드 리뷰 스코어 산출 Script
# Date : 2018.05.17
# Writer : 김남윤
#=================================================================================================================
options(java.parameters = "-Xmx5g")
library(dplyr)
library(stringi)
library(NLP4kec)
library(readr)
library(data.table)
library(tm)
library(wordVectors)
library(stringr)
library(slam)

source("/home/r_srcs/apa/batch_job/ref_function/tm_function.R")
source("/home/r_srcs/apa/batch_job/ref_function/createImpalaConnection.R")
connImpala = getImpalaConnection()

# 날짜 세팅하기!!
start_date = "2017-12-01"
end_date = Sys.Date()

start_date = paste0(stri_replace_all_fixed(start_date, "-",""), "000000")
end_date = paste0(stri_replace_all_fixed(end_date, "-",""), "235959")

# 1. Data Load for Review ----------------------------------------------------------------------------------------

# 뷰티포인트 리뷰 데이터 가져오기
query = paste0(
"SELECT
  bltncntseq
  ,regid
  ,regdt
  ,regexp_replace(cnt, '<[^>]*>|\\&([^;])*;','') as cnt_rep
FROM lake_legacy_ods.etm_ketd06mt
WHERE bbscd in ('BB11','BB07')
AND regdt BETWEEN '", start_date, "' AND '", end_date, "';"
)
raw_review = dbGetQuery(connImpala, query)
colnames(raw_review) = c("v_reviewcd","user_id","reg_date","v_content")

#날짜 생성
raw_review = raw_review %>% mutate(regYear = substr(reg_date,1,4)
                                     ,regMonth = substr(reg_date,5,6)
                                     ,regDay = substr(reg_date,7,8)
                                     ,regHour = substr(reg_date,9,10))

#에뛰드는 상품코드를 붙일 수 없는듯....

# NA 제거
raw_review =  raw_review %>% filter(!is.na(v_content))

# 전처리
raw_review$v_content = gsub(",","",raw_review$v_content)
raw_review$v_content = gsub("\"","'",raw_review$v_content)
raw_review$v_content = stri_replace_all_regex(raw_review$v_content, pattern = "[\x80-\xFF]", replacement = "")



# 2. 리뷰별 리뷰 점수 구하기 -----------------------------------------------------------------------------------------------------------------------
#형태소 분석
parsedText = r_parser_r(raw_review$v_content
                        , language = "ko"
                        , korDicPath = "/home/r_srcs/apa/batch_job/dictionary/dictionary.txt")

# 불용어, 동의어 사전 읽어오기
stopWordDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/stopword_ko.csv")
synonymDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/synonym", trim_ws = F)

# 동의어 처리
parsedText = synonymProcess(targetParsedSet = parsedText)

# make dtm
dtm = makeDtm(parsedText, sr = 0.9999, dtmType = "tf")

m = t(dtm)
cs = col_sums(m) # 총 단어 빈도
m$v = m$v/cs[m$j]

# 고정 IDF값 가져오기
idf_val = readRDS("/home/r_srcs/apa/batch_job/model/idf_tb_inni_0425.RDS")

targetTerm = m$dimnames[1]
targetTerm = targetTerm$Terms
sub_idf_val = idf_val[word %in% targetTerm]

m = m[targetTerm %in% sub_idf_val$word,]

m = m * sub_idf_val$idf_val
dtmMat = as.matrix(t(m))


# 형태소 분석 결과 붙이기
raw_review$parsedText = parsedText

# 문서별 점수 구하기
raw_review$tnDl = rowSums(dtmMat) * nchar(raw_review$v_content)

# 원문 Data set에 붙이기
raw_review$rown = rownames(raw_review)
raw_review$row_sum = rowSums(dtmMat)
raw_review$char_n = nchar(raw_review$v_content)
raw_review$term_n = apply(dtmMat, 1, function(x){length(which(x>0))})
raw_review$bestYn = ifelse(raw_review$tnDl >= 1000, TRUE, FALSE)


# 조건에 안 맞는 베스트 리뷰 보정하기 - 단어 개수가 너무 적은 리뷰는 베스트 리뷰에서 제외
modify_target_review = raw_review %>% filter(term_n < 15, bestYn == TRUE) %>% select(v_reviewcd)
raw_review$bestYn[raw_review$id %in% modify_target_review$v_reviewcd] = FALSE


# 3.베스트리뷰 개수 ----------------------------------------------------------------------------------------------------
raw_review %>% group_by(bestYn) %>% summarise(n = n())

