#=================================================================================================================
# AP몰 리뷰 스코어링 Batch job
# Date : 2018.05.14
# Writer : 김남윤
#=================================================================================================================
options(java.parameters = "-Xmx5g")
library(dplyr)
library(stringi)
library(NLP4kec)
library(readr)
library(data.table)
library(tm)
library(wordVectors)
library(stringr)
library(slam)

source("/home/r_srcs/apa/batch_job/ref_function/tm_function.R")
source("/home/r_srcs/apa/batch_job/ref_function/createImpalaConnection.R")
connImpala = getImpalaConnection()

# 날짜 만들기
start_date = Sys.Date() - 1
end_date = Sys.Date() - 1

#start_date = "2018-05-01"
#end_date = "2018-05-13"

start_date = paste0(stri_replace_all_fixed(start_date, "-",""), "000000")
end_date = paste0(stri_replace_all_fixed(end_date, "-",""), "235959")

# 1. Data Load for Review ----------------------------------------------------------------------------------------

# 1-1. 리뷰 원문
query = paste0(
"SELECT 
  o.v_reviewcd
  ,o.v_userid
  ,o.v_typecd
  ,o.v_ordercd
  ,o.n_recom_point
  ,o.n_vote_cnt
  ,o.n_view_cnt
  ,o.v_content
  ,o.v_reg_channel
  ,o.v_reg_dtm
  FROM bdsdb.o_cmc_review o
  WHERE o.v_reg_dtm BETWEEN '", start_date, "' AND '", end_date, "';"
)
raw_review = dbGetQuery(connImpala, query)

# 1-2. 리뷰ID*상품코드
query = 
  "SELECT 
DISTINCT o.v_reviewcd
,o.v_productcd
FROM bdsdb.o_cmc_review_prod o
WHERE v_reg_type='USER'"
raw_reviewXproudct = dbGetQuery(connImpala, query)

#날짜 생성
raw_review2 = raw_review %>% mutate(regYear = substr(v_reg_dtm,1,4)
                                    ,regMonth = substr(v_reg_dtm,5,6)
                                    ,regDay = substr(v_reg_dtm,7,8)
                                    ,regHour = substr(v_reg_dtm,9,10))

# 리뷰데이터에 온라인 상품ID, 옵션ID 붙이기
raw_review2 = merge(raw_review2, raw_reviewXproudct, by = "v_reviewcd", all.x = T)

# 중복제거
raw_review2 = raw_review2[!duplicated(raw_review2$v_reviewcd),]

# NA 제거
raw_review2 = raw_review2 %>% filter(!is.na(v_content))

# 원문 특수기호 정리하기
raw_review2$v_content = gsub(",","",raw_review2$v_content)
raw_review2$v_content = gsub("\"","'",raw_review2$v_content)
raw_review2$v_content = stri_replace_all_regex(raw_review2$v_content, pattern = "[\x80-\xFF]", replacement = "")

# 상품 마스터 정보
query = 
"SELECT 
  p.ap_prd_cd as v_productcd,
  p.cem_prd_nm_n,
  p.prd_ltyp_nm_n,
  p.prd_mtyp_nm_n,
  p.prd_styp_nm_n,
  p.brand_nm,
  p.v_status_cd,
  p.v_comment,
  p.n_list_price,
  p.n_price,
  p.n_vip_price,
  p.n_point,
  p.v_coupon_yn,
  p.base_date
FROM campdb.product_master_not_dup_for_apmall p
WHERE p.n_price is not NULL;"
raw_product2 = dbGetQuery(connImpala, query)


# 2. 리뷰별 리뷰 점수 구하기 -----------------------------------------------------------------------------------------------------------------------
#형태소 분석
parsedText = r_parser_r(raw_review2$v_content
                        , language = "ko"
                        , korDicPath = "/home/r_srcs/apa/batch_job/dictionary/dictionary.txt")

# 불용어, 동의어 사전 읽어오기
stopWordDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/stopword_ko.csv")
synonymDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/synonym", trim_ws = F)

# 동의어 처리
parsedText = synonymProcess(targetParsedSet = parsedText)

# make dtm
dtm = makeDtm(parsedText, sr = 0.9999, dtmType = "tf")

m = t(dtm)
cs = col_sums(m) # 총 단어 빈도
m$v = m$v/cs[m$j]

# 고정 IDF값 가져오기
idf_val = readRDS("/home/r_srcs/apa/batch_job/model/idf_tb_apmall_0514.RDS")

targetTerm = m$dimnames[1]
targetTerm = targetTerm$Terms
sub_idf_val = idf_val[word %in% targetTerm]

m = m[targetTerm %in% sub_idf_val$word,]

m = m * sub_idf_val$idf_val
dtmMat = as.matrix(t(m))


# 형태소 분석 결과 붙이기
raw_review2$parsedText = parsedText

# 문서별 점수 구하기
raw_review2$tnDl = rowSums(dtmMat) * nchar(raw_review2$v_content)

# 원문 Data set에 붙이기
raw_review2$rown = rownames(raw_review2)
raw_review2$row_sum = rowSums(dtmMat)
raw_review2$char_n = nchar(raw_review2$v_content)
raw_review2$term_n = apply(dtmMat, 1, function(x){length(which(x>0))})
raw_review2$bestYn = ifelse(raw_review2$tnDl >= 1000, TRUE, FALSE)


# 조건에 안 맞는 베스트 리뷰 보정하기 - 단어 개수가 너무 적은 리뷰는 베스트 리뷰에서 제외
modify_target_review = raw_review2 %>% filter(term_n < 15, bestYn == TRUE) %>% select(v_reviewcd)
raw_review2$bestYn[raw_review2$v_reviewcd %in% modify_target_review$v_reviewcd] = FALSE


# 3. 배송/서비스 관련 리뷰 태깅하기 ----------------------------------------------------------------------------------------------------
# word cosine 유사도 불러오기
word_cosine_simility = readRDS("/home/r_srcs/apa/batch_job/model/total_review_cosSim_0514.RDS")

# 속성 키워드 세팅
att_keyword = c("지연","배송","상담원")

# TDM 만들기
tdm_mat = makeDtm(parsedText, 0.999, "tdm-tf")
tdm_mat = as.matrix(tdm_mat)

#속성 스코어 구하기
att_score = getAttributeScore(word_cosine_simility, tdm_mat, att_keyword, cutOff = 0.7)

#원천 테이블에 스코어 붙이기
raw_review2 = cbind(raw_review2, att_score$docScore)

# 배송/서비스 관련 리뷰 보정하기
raw_review2 = raw_review2 %>% mutate(tag = case_when((배송>0 | 지연>0 | 상담원>0) ~ "delivery/service"))


# 4.Insert 타겟 대상 만들기 ----------------------------------------------------------------------------------------------------
raw_review2 = merge(raw_review2, raw_product2, by = "v_productcd", all.x = T)

insert_target_review = raw_review2 %>% select(v_reviewcd, v_typecd, v_reg_channel, v_reg_dtm, parsedText, v_productcd, tnDl, char_n, term_n, bestYn, tag)
insert_target_review$etl_dtm = Sys.time()


# 5. Insert DB ---------------------------------------------------------------------------------------------------------------
makeValue = function(x){
  v1 = paste0("cast('", trimws(x[1]),"' as varchar(21))")
  v2 = paste0("cast('", trimws(x[2]),"' as varchar(5))")
  v3 = paste0("cast('", trimws(x[3]),"' as varchar(7))")
  v4 = paste0("cast('", trimws(x[4]),"' as varchar(14))")
  v5 = paste0("cast('", trimws(x[5]),"' as varchar(400))")
  v6 = paste0("cast('", trimws(x[6]),"' as varchar(30))")
  v7 = paste0("cast('", trimws(x[7]),"' as FLOAT)")
  v8 = paste0("cast('", trimws(x[8]),"' as INT)")
  v9 = paste0("cast('", trimws(x[9]),"' as INT)")
  v10 = paste0("cast('", trimws(x[10]),"' as varchar(5))")
  v11 = paste0("cast('", trimws(x[11]),"' as varchar(20))")
  v12 = paste0("cast('", trimws(x[12]),"' as TIMESTAMP)")
  
  return(paste(v1,",",v2,",",v3,",",v4,",",v5,",",v6,",",v7,",",v8,",",v9,",",v10,",",v11,",",v12))
}

batch = apply(insert_target_review, 1, makeValue) %>% paste0("(",.,")", collapse = ",\n")
query = paste("INSERT INTO CAMPDB.apmall_review_score VALUES", batch)

st = Sys.time()
dbSendUpdate(connImpala, query)
ed = Sys.time()

dur = ed - st

print(paste0("Insert Time: ", dur, " at ", Sys.time()))
print(paste0("Review-Score batch job completed successfully at ", Sys.time()))

