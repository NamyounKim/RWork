#=================================================================================================================
# 뷰티포인트 리뷰 스코어 산출 Script
# Date : 2018.05.14
# Writer : 김남윤
#=================================================================================================================
options(java.parameters = "-Xmx5g")
library(dplyr)
library(stringi)
library(NLP4kec)
library(readr)
library(data.table)
library(tm)
library(wordVectors)
library(stringr)
library(slam)

source("/home/r_srcs/apa/batch_job/ref_function/tm_function.R")
source("/home/r_srcs/apa/batch_job/ref_function/createImpalaConnection.R")
connImpala = getImpalaConnection()

# 날짜 세팅하기!!
start_date = "2017-12-01"
end_date = "2018-05-14"

start_date = paste0(stri_replace_all_fixed(start_date, "-",""), "000000")
end_date = paste0(stri_replace_all_fixed(end_date, "-",""), "235959")

# 1. Data Load for Review ----------------------------------------------------------------------------------------

# 뷰티포인트 리뷰 데이터 가져오기
query = paste0(
"SELECT 
  b.review_no,
  b.review_kind,
  b.review_title,
  b.reviewer,
  b.review_strength,
  b.review_weakness,
  b.review_etc,
  b.product_cd,
  b.input_date
FROM lake_legacy_ods.bpa_bp_review b
WHERE b.input_date BETWEEN '", start_date, "' AND '", end_date, "';"
)
raw_review = dbGetQuery(connImpala, query)

#날짜 생성
raw_review = raw_review %>% mutate(regYear = substr(input_date,1,4)
                                     ,regMonth = substr(input_date,5,6)
                                     ,regDay = substr(input_date,7,8)
                                     ,regHour = substr(input_date,9,10))

#상품 기본정보 가져오기
query = 
"SELECT
  p.product_cd
  ,p.site_cd
  ,p.site_product_cd
  ,p.site_sap_cd
  ,p.product_nm
  ,p.category_cd1
  ,p.brand_nm
  ,p.price
  ,p.description
FROM lake_legacy_ods.bpa_bp_product p;"
raw_product = dbGetQuery(connImpala, query)

raw_review = merge(raw_review, raw_product, by = "product_cd", all.x = T)


# 리뷰 합친것
raw_review_all = raw_review %>% dplyr::select(review_no, input_date, review_strength, review_weakness, review_etc, brand_nm, product_nm, site_product_cd)
raw_review_all$review_etc[is.na(raw_review_all$review_etc)] = ""
raw_review_all = raw_review_all %>% mutate(v_content = paste(review_strength, review_weakness, review_etc, sep = " "))

raw_review_all = raw_review_all %>% select(review_no, input_date, v_content, brand_nm, product_nm, site_product_cd)
colnames(raw_review_all) = c("id","regDate","v_content","brand_nm","product_nm","site_product_cd")
raw_review_all$v_content = gsub(",","",raw_review_all$v_content)
raw_review_all$v_content = gsub("\"","'",raw_review_all$v_content)
raw_review_all$v_content = stri_replace_all_regex(raw_review_all$v_content, pattern = "[\x80-\xFF]", replacement = "")


# 2. 리뷰별 리뷰 점수 구하기 -----------------------------------------------------------------------------------------------------------------------
#형태소 분석
parsedText = r_parser_r(raw_review_all$v_content
                        , language = "ko"
                        , korDicPath = "/home/r_srcs/apa/batch_job/dictionary/dictionary.txt")

# 불용어, 동의어 사전 읽어오기
stopWordDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/stopword_ko.csv")
synonymDic = read_csv("/home/r_srcs/apa/batch_job/dictionary/synonym", trim_ws = F)

# 동의어 처리
parsedText = synonymProcess(targetParsedSet = parsedText)

# make dtm
dtm = makeDtm(parsedText, sr = 0.9999, dtmType = "tf")

m = t(dtm)
cs = col_sums(m) # 총 단어 빈도
m$v = m$v/cs[m$j]

# 고정 IDF값 가져오기
idf_val = readRDS("/home/r_srcs/apa/batch_job/model/idf_tb_bp_0425.RDS")

targetTerm = m$dimnames[1]
targetTerm = targetTerm$Terms
sub_idf_val = idf_val[word %in% targetTerm]

m = m[targetTerm %in% sub_idf_val$word,]

m = m * sub_idf_val$idf_val
dtmMat = as.matrix(t(m))


# 형태소 분석 결과 붙이기
raw_review_all$parsedText = parsedText

# 문서별 점수 구하기
raw_review_all$tnDl = rowSums(dtmMat) * nchar(raw_review_all$v_content)

# 원문 Data set에 붙이기
raw_review_all$rown = rownames(raw_review_all)
raw_review_all$row_sum = rowSums(dtmMat)
raw_review_all$char_n = nchar(raw_review_all$v_content)
raw_review_all$term_n = apply(dtmMat, 1, function(x){length(which(x>0))})
raw_review_all$bestYn = ifelse(raw_review_all$tnDl >= 1000, TRUE, FALSE)


# 조건에 안 맞는 베스트 리뷰 보정하기 - 단어 개수가 너무 적은 리뷰는 베스트 리뷰에서 제외
modify_target_review = raw_review_all %>% filter(term_n < 15, bestYn == TRUE) %>% select(id)
raw_review_all$bestYn[raw_review_all$id %in% modify_target_review$id] = FALSE



# 3.Insert 타겟 대상 만들기 ----------------------------------------------------------------------------------------------------
target_data = raw_review_all %>% select(id, regDate, brand_nm, product_nm, parsedText, tnDl, char_n, term_n, bestYn)

# 4.베스트리뷰 개수 ----------------------------------------------------------------------------------------------------
target_data %>% group_by(bestYn) %>% summarise(n = n())

