library(dplyr)
library(stringi)
library(stringr)
library(parallel)
library(data.table)

library(wordVectors)
library(tsne)


makeTrainSetOne = function(i){
  
  temp = sub_log_one[sub_log_one$sid == uniqueSid_one[i]]
  prdList = stri_paste(temp$prdId, collapse = " ")
  
  trainSet = data.table(sid = uniqueSid_one[i], prdList = prdList)
  
  return(trainSet)
}
makeTrainSetFive = function(i){
  
  temp = sub_log_five[sub_log_five$sid == uniqueSid_five[i]]
  prdList = stri_paste(temp$prdId, collapse = " ")
  
  trainSet = data.table(sid = uniqueSid_five[i], prdList = prdList)
  
  return(trainSet)
}

startTime = Sys.time()
trainSet_one = mclapply(1:length(uniqueSid_one), makeTrainSetOne, mc.cores = 15)
trainSet_one = rbindlist(trainSet_one)
endTime = Sys.time()
endTime - startTime

startTime = Sys.time()
trainSet_five = mclapply(1:length(uniqueSid_five), makeTrainSetFive, mc.cores = 15)
trainSet_five = rbindlist(trainSet_five)
endTime = Sys.time()
endTime - startTime



write.table(trainSet_one %>% select(prdList), file = "./trainSet_one.txt", row.names = F, col.names = F, quote = F)
write.table(trainSet_five %>% select(prdList), file = "./trainSet_five.txt", row.names = F, col.names = F, quote = F)


model_one = train_word2vec(train_file = "./trainSet_one.txt"
                           , threads = 10
                           , vectors = 100
                           , window = 5)

model_five = train_word2vec(train_file = "./trainSet_five.txt"
                           , threads = 10
                           , vectors = 100
                           , window = 5)

model_one = model_one[rownames(model_one) != "</s>",]
model_five = model_five[rownames(model_five) != "</s>",]

# 결과 체크 -------------------------------------------------------------------------------------------------------------------
nearest_to(model_one, model_one[["SPR20180124000036389"]])
nearest_to(model_five, model_five[["SPR20180124000036389"]])

ap_product_marster[v_productcd == "P00003042"]
ap_product_marster[v_productcd %in% names(nearest_to(model_one, model_one[["SPR20170814000031589"]]))]
ap_product_marster[v_productcd %in% names(nearest_to(model_five, model_five[["SPR20170814000031589"]]))]
#------------------------------------------------------------------------------------------------------------------------------

cosSim_one = as.data.frame(cosineSimilarity(model_one, model_one))
cosSim_one$prdId = row.names(cosSim_one)
itemCosSim_one = melt(cosSim_one, id=c("prdId"))
itemCosSim_one = itemCosSim_one %>% filter(prdId != variable, value > 0)


cosSim_five = as.data.frame(cosineSimilarity(model_five, model_five))
cosSim_five$prdId = row.names(cosSim_five)
itemCosSim_five = melt(cosSim_five, id=c("prdId"))
itemCosSim_five = itemCosSim_five %>% filter(prdId != variable, value > 0)


plot(model)
#saveRDS(trainSet, "./trainSet_201801.RDS")
