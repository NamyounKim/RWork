options(java.parameters = "-Xmx20g")
source("~/rwork/createImpalaConnection.R")
connImpala = getImpalaConnection()

# Data Load ---------------------------------------------------------------------------------------------------------------
apmall_raw_log = readRDS("../APmallLogAnalysis/data/apmall_raw_log_201803.RDS")
apmall_raw_log = as.data.table(apmall_raw_log)

# 4. 상품의 브랜드, 카테고리 정보
query = 
  "SELECT 
p.ap_prd_cd as v_productcd,
p.cem_prd_nm_n,
p.prd_ltyp_nm_n,
p.prd_mtyp_nm_n,
p.prd_styp_nm_n,
p.brand_nm
FROM campdb.product_master_not_dup_for_apmall p
WHERE p.n_price is not NULL;"
ap_product_marster = dbGetQuery(connImpala, query)
ap_product_marster = as.data.table(ap_product_marster)

apmall_raw_log$prdId = stri_replace_all_fixed(stri_match_first_regex(apmall_raw_log$pg_url, 
                                                                   pattern = "sProductcd=[A-Za-z0-9]+"),"sProductcd=","")

sub_log = apmall_raw_log[!is.na(prdId), .(sid, wlg_conn_dttm_nm, prdId)]
  #apmall_raw_log %>% filter(!is.na(prdId)) %>% select(sid, wlg_conn_dttm_nm, prdId)

countPvOne = sub_log[,.(n=.N), by=sid][n==1]
countPvFive = sub_log[,.(n=.N), by=sid][n<=5]

sub_log = left_join(sub_log, ap_product_marster, by = c("prdId"="v_productcd")) %>% arrange(sid, wlg_conn_dttm_nm) %>% as.data.table()


sub_log_one = sub_log[!sid %in% countPvOne$sid]   # PV가 1인 세션 삭제
sub_log_five = sub_log[!sid %in% countPvFive$sid] # PV가 5인 세션 삭제

uniqueSid_one = unique(sub_log_one$sid)
uniqueSid_five = unique(sub_log_five$sid)