library(recommenderlab)
library(stringi)
library(reshape2)
library(arules)
library(data.table)
library(dplyr)

source("./recommendFunction.R")

product_pv_agg = sub_log_one[,.(n=.N), by=.(sid, prdId)]

start = Sys.time()
product_pv_spvm = dcast.data.table(product_pv_agg, sid ~ prdId, sum, value.var = "n")
end = Sys.time()
end-start

# Convert to Rating Matrix & Get Similarity (Product Vector, 최소 상품당 PV, 최소 세션별 PV)
product_pv_rm =  makeRatingMatrix(product_pv_spvm, keyCol = "sid", colLimit = 50, rowLimit = 5)

## Recommender Modeling ##
recoModel = Recommender(product_pv_rm, method="IBCF", param=list(method="Jaccard", alpha = 0.1))
end = Sys.time()
end-start


## Print Item Simility ##
itemMat = as(getModel(recoModel)$sim, "matrix")
itemMatDf = as.data.frame(itemMat)

# 결과 체크 -------------------------------------------------------------------------------------------------------------------
names(sort(itemMat[,"SPR20180124000036389"], decreasing = T)[1:10])
ap_product_marster[v_productcd %in% names(sort(itemMat[,"SPR20170814000031589"], decreasing = T)[1:10])]
# -----------------------------------------------------------------------------------------------------------------------------

itemMatDf$prdId = row.names(itemMatDf)
itemSim = melt(itemMatDf, id=c("prdId"))
itemSim = itemSim %>% filter(prdId != variable, value > 0)

saveRDS(itemMatDf,"./itemMatDf.RDS")

itemMatDf %>% select(brandNm, 해피바스) %>% arrange(-해피바스)


